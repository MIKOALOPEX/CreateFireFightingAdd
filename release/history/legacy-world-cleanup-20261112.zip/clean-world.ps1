﻿param(
    [string]$Source,
    [string]$Output,
    [string]$DestinationRoot,
    [switch]$AllLegacy
)
$ErrorActionPreference = 'Stop'
Write-Host '旧存档清理工具 v2：只生成新副本，原存档不覆盖。' -ForegroundColor Cyan
Write-Host '请先关闭游戏或服务端。保留旧整合包及原存档。'
if ($AllLegacy) {
    Write-Host '本次删除：全部旧消防方块、物品及关联连接。' -ForegroundColor Yellow
} else {
    Write-Host '本次删除：旧动力组件、共用支架及关联连接。' -ForegroundColor Yellow
}
Write-Host '相关约束提供方块按坐标清除；不直接删除整个 Sable 子结构。' -ForegroundColor Yellow
if (-not $Source) { $Source = (Read-Host '请输入原世界文件夹路径（包含 level.dat）').Trim('"') }
$item = Get-Item -LiteralPath $Source
if (-not $Output) {
    if (-not $DestinationRoot) { $DestinationRoot = $item.Parent.FullName }
    $mode = if ($AllLegacy) { 'all' } else { 'powertrain' }
    $worldName = 'CLEANUP-v2-' + $mode + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $item.Name
    $Output = Join-Path $DestinationRoot $worldName
}
$Output = [System.IO.Path]::GetFullPath($Output)
Write-Host "输出目录：$Output" -ForegroundColor Cyan
Write-Host ('游戏中请选择：' + [System.IO.Path]::GetFileName($Output)) -ForegroundColor Cyan
$cleanup = Join-Path $PSScriptRoot 'tools\world_cleanup\clean_world.py'
$pythonArgs = @($cleanup, $Source, '--output', $Output)
if ($AllLegacy) { $pythonArgs += '--all-legacy' }
$log = Join-Path $PSScriptRoot 'cleanup-last-run.log'
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 @pythonArgs 2>&1 | Tee-Object -FilePath $log
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python @pythonArgs 2>&1 | Tee-Object -FilePath $log
} else {
    throw '需要 Python 3.10 或更新版本，请安装后重新运行。'
}
if ($LASTEXITCODE -ne 0) { throw "清理失败，原档未修改。日志：$log" }
$receipt = Join-Path $PSScriptRoot 'LAST_SUCCESSFUL_CLEANUP.txt'
@(
    '最近一次成功清理；此前测试副本不会自动更新。',
    ('完成时间：' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')),
    ('游戏中请选择：' + [System.IO.Path]::GetFileName($Output)),
    ('输出文件夹：' + $Output),
    ('来源：' + $Source),
    '此结果尚未通过游戏载入验收。'
) | Set-Content -LiteralPath $receipt -Encoding UTF8
Write-Host ''
Write-Host '清理完成，请在游戏中选择下面这个世界：' -ForegroundColor Green
Write-Host ([System.IO.Path]::GetFileName($Output)) -ForegroundColor Green
Write-Host "完整路径：$Output"
Write-Host "结果记录：$receipt"
