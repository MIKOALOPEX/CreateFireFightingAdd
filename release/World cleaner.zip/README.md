# World cleaner

Back up your world and close Minecraft/server first. Install Python 3.10+ and run Clean_Old_World.bat. Select an existing export directory, then the source world. All processing is local and creates a separate copy; reserve enough disk space. Close the window after completion.

This fallback removes legacy components and identifiable constraint-provider blocks without deleting whole substructures. Read docs/legacy-world-cleanup.md and docs/transition-029-player-text.md before use.
