# 0.2.9-beta instructions / 操作说明

完整中英文说明已合并至本目录 [README](./README.md)，进入 GitHub 的 release 目录即可阅读。

The complete English and Chinese instructions are maintained in this directory's [README](./README.md), displayed when browsing the release folder on GitHub.
